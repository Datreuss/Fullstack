const productos = [
    { 
        id: 1, 
        nombre: "Paracetamol 500mg x 20", 
        precio: 2990, 
        categoria: "Analgésicos", 
        stock: 145, 
        imagen: "img/paracetamol.png", 
        icono: "fa-pills" 
    },
    { 
        id: 2, 
        nombre: "Ibuprofeno 400mg x 30", 
        precio: 3890, 
        categoria: "Antiinflamatorios", 
        stock: 12, 
        imagen: "img/ibuprofeno.png", 
        icono: "fa-capsules" 
    },
    { 
        id: 3, 
        nombre: "Vitamina C Efervescente", 
        precio: 4500, 
        categoria: "Suplementos", 
        stock: 85, 
        imagen: "img/vitamina c.jpg", 
        icono: "fa-tablets" 
    },
    { 
        id: 4, 
        nombre: "Alcohol 500ml", 
        precio: 2490, 
        categoria: "Cuidado Personal", 
        stock: 5, 
        imagen: "img/alcohol.png", 
        icono: "fa-pump-soap" 
    },
    { 
        id: 5, 
        nombre: "Omeprazol 20mg x 30", 
        precio: 5190, 
        categoria: "Gastroenterología", 
        stock: 64, 
        imagen: "img/omeprazol.png", 
        icono: "fa-pills" 
    },
    { 
        id: 6, 
        nombre: "Aspirina 100mg x 40", 
        precio: 3490, 
        categoria: "Cardiovascular", 
        stock: 3, 
        imagen: "img/aspirina.png", 
        icono: "fa-tablets" 
    }
];

let carrito = [];

const comunasPorRegion = {
    rm: ["Maipú", "Santiago", "Las Condes", "Puente Alto", "Maipú Centro", "Ñuñoa", "Providencia"],
    valparaiso: ["Valparaíso", "Viña del Mar", "Concón", "Quilpué", "Villa Alemana"],
    biobio: ["Concepción", "Talcahuano", "San Pedro de la Paz", "Chiguayante"]
};

function switchView(viewId) {
    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(viewId).classList.add('active');

    document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
    if(viewId === 'vista-cliente') document.getElementById('nav-cliente').classList.add('active');
    if(viewId === 'vista-checkout') {
        document.getElementById('nav-checkout').classList.add('active');
        actualizarTotalCheckout();
    }
    window.scrollTo(0, 0);
}

function cargarCatalogo() {
    const container = document.getElementById('product-list');
    container.innerHTML = productos.map(p => `
        <div class="product-card">
            <div>
                <div class="product-img">
                    ${p.imagen ? `<img src="${p.imagen}" alt="${p.nombre}">` : `<i class="fa-solid ${p.icono}"></i>`}
                </div>
                <div class="product-title">${p.nombre}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">${p.categoria}</div>
            </div>
            <div>
                <div class="product-price">$${p.precio.toLocaleString('es-CL')}</div>
                <button class="btn-primary" onclick="agregarAlCarro(${p.id})"><i class="fa-solid fa-cart-plus"></i> Agregar</button>
            </div>
        </div>
    `).join('');
}

function agregarAlCarro(id) {
    const prod = productos.find(p => p.id === id);
    carrito.push(prod);
    document.getElementById('cart-count').innerText = carrito.length;
    alert(`¡${prod.nombre} agregado al carrito con éxito!`);
}

function actualizarTotalCheckout() {
    const total = carrito.reduce((sum, item) => sum + item.precio, 0);
    document.getElementById('checkout-total').innerText = `$${total.toLocaleString('es-CL')}`;
}

function actualizarComunas() {
    const region = document.getElementById('region-select').value;
    const selectComuna = document.getElementById('comuna-select');
    selectComuna.innerHTML = '<option value="">Seleccione comuna...</option>';
    if(comunasPorRegion[region]) {
        comunasPorRegion[region].forEach(c => {
            selectComuna.innerHTML += `<option value="${c}">${c}</option>`;
        });
    }
}

function toggleDeptoField() {
    const tipo = document.getElementById('tipo-vivienda').value;
    const groupDepto = document.getElementById('group-numdepto');
    if(tipo === 'depa') {
        groupDepto.style.display = 'block';
    } else {
        groupDepto.style.display = 'none';
        document.getElementById('num-depto').value = '';
    }
}

function procesarCompra(event) {
    event.preventDefault();
    let isValid = true;

    const campos = ['nombre', 'apellido', 'edad', 'region-select', 'comuna-select', 'direccion', 'tipo-vivienda'];
    campos.forEach(id => {
        const el = document.getElementById(id);
        const group = document.getElementById(`group-${id.replace('-select','')}`);
        if (!el.value.trim()) {
            group.classList.add('error');
            isValid = false;
        } else {
            group.classList.remove('error');
        }
    });

    const tipoVivienda = document.getElementById('tipo-vivienda').value;
    if (tipoVivienda === 'depa') {
        const deptoEl = document.getElementById('num-depto');
        const groupDepto = document.getElementById('group-numdepto');
        if (!deptoEl.value.trim()) {
            groupDepto.classList.add('error');
            isValid = false;
        } else {
            groupDepto.classList.remove('error');
        }
    }

    if (!isValid) {
        alert('Por favor complete todos los campos obligatorios marcados en rojo.');
        return;
    }

    if (carrito.length === 0) {
        alert('Tu carrito está vacío. Agrega productos antes de comprar.');
        switchView('vista-cliente');
        return;
    }

    alert('¡Compra realizada con éxito en SaludPlus! Gracias por su preferencia.');
    carrito = [];
    document.getElementById('cart-count').innerText = '0';
    document.getElementById('checkout-form').reset();
    switchView('vista-cliente');
}

function ingresarAdmin(e) {
    e.preventDefault();
    switchView('vista-admin-dashboard');
    cargarTablaAdmin();
}

function ingresarInventario(e) {
    e.preventDefault();
    switchView('vista-inventario-dashboard');
    cargarTablaInventario();
}

function cargarTablaAdmin() {
    const tbody = document.getElementById('admin-orders-table');
    tbody.innerHTML = `
        <tr><td>#ORD-9021</td><td>Marcela Gómez</td><td>Maipú</td><td>$7.480</td><td><span class="badge success">Completado</span></td></tr>
        <tr><td>#ORD-9020</td><td>Carlos Soto</td><td>Santiago</td><td>$4.500</td><td><span class="badge warning">En Ruta</span></td></tr>
        <tr><td>#ORD-9019</td><td>Ana Torres</td><td>Providencia</td><td>$12.300</td><td><span class="badge success">Completado</span></td></tr>
    `;
}

function cargarTablaInventario() {
    const tbody = document.getElementById('inventory-table');
    tbody.innerHTML = productos.map(p => `
        <tr>
            <td>SP-${100 + p.id}</td>
            <td>${p.nombre}</td>
            <td>${p.categoria}</td>
            <td><b>${p.stock}</b> un.</td>
            <td>${p.stock <= 5 ? '<span class="badge warning" style="background:#fee2e2; color:#991b1b;">Stock Crítico</span>' : '<span class="badge success">Óptimo</span>'}</td>
        </tr>
    `).join('');
}

window.onload = function() {
    cargarCatalogo();
};